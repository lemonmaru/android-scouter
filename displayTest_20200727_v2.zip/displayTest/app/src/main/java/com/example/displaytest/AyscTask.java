package com.example.displaytest;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class AyscTask extends AsyncTask<String, Void, String> {

    private Activity mActivity;
    private View mView;
    private TextView mTextViewDept;
    private TextView mTextViewName;
    private TextView mTextViewPower;

    public AyscTask(Activity activity, View view, TextView textViewDept, TextView textViewName, TextView textViewPower) {
        mActivity = activity;
        mView = view;
        mTextViewDept = textViewDept;
        mTextViewName = textViewName;
        mTextViewPower = textViewPower;
    }

    @Override
    protected String doInBackground(String... params) {
        StringBuffer result = new StringBuffer();

        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(params[0]);

            urlConnection = (HttpURLConnection) url.openConnection();
            Gson gson = new Gson();

            // Personクラスの配列を、JSON文字列に変換する
            InputJson ij = new InputJson(params[1], params[2]);
            String json = gson.toJson(ij, InputJson.class);

            urlConnection.setRequestProperty("Content-Length", String.valueOf(json.length()));
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setConnectTimeout(100000);
            urlConnection.setReadTimeout(100000);
            urlConnection.setRequestMethod("POST");
            // データがJSONであること、エンコードを指定する
            urlConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            OutputStreamWriter out = new OutputStreamWriter(urlConnection.getOutputStream());

            out.write(json);
            out.flush();

            urlConnection.connect();
            int status = urlConnection.getResponseCode();

            //通信成功の場合
            InputStream in = null;
            if (status == HttpURLConnection.HTTP_OK) {
                // テキストを取得する
                in = urlConnection.getInputStream();
            } else {
                in = urlConnection.getErrorStream();
            }
            //String encoding = urlConnection.getContentEncoding();
            String encoding = "UTF-8";

            final InputStreamReader inReader = new InputStreamReader(in, encoding);
            final BufferedReader bufReader = new BufferedReader(inReader);
            String line = null;
            // 1行ずつテキストを読み込む
            while ((line = bufReader.readLine()) != null) {
                result.append(line);
            }
            bufReader.close();
            inReader.close();
            in.close();

            //Log.d("呼び出し結果(doInBuck)", result.toString());
            //Log.d("呼び出し結果(doInBuck)", Integer.toString(status));
            //Log.d("呼び出し結果(doInBuck)", urlConnection.getResponseMessage());

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        return result.toString();
    }

    public void onPostExecute(String string) {

        Gson gson = new Gson();
        Example example = gson.fromJson(string, Example.class);
        Log.d("所属部署", example.body.dept);
        Log.d("内線番号", example.body.tel);
        Log.d("社員番号", example.body.empNum);
        Log.d("氏名", example.body.name);
        Log.d("役職", example.body.position);
        Log.d("パワー", Float.toString(example.body.power));

        //Snackbar.make(mView, example.body.dept + " " + example.body.name + " " + Float.toString(example.body.power), Snackbar.LENGTH_LONG)
        //        .setAction("Action", null).show();

        mTextViewDept.setText("所属　：" + example.body.dept);
        mTextViewName.setText("氏名　：" + example.body.name + example.body.position);
        mTextViewPower.setText("戦闘力：" + Float.toString(example.body.power));
    }
}
