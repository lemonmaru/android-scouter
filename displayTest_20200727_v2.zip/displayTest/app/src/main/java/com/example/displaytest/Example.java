
package com.example.displaytest;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Example {

    @SerializedName("statusCode")
    @Expose
    public Integer statusCode;
    @SerializedName("headers")
    @Expose
    public Headers headers;
    @SerializedName("body")
    @Expose
    public Body body;

}
