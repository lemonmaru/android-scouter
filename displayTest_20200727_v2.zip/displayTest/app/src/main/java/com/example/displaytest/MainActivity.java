package com.example.displaytest;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;



public class MainActivity extends AppCompatActivity {

    private TextView textViewDept;
    private TextView textViewName;
    private TextView textViewPower;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);

        TextView textViewDept = findViewById(R.id.text_view_dept);
        TextView textViewName = findViewById(R.id.text_view_name);
        TextView textViewPower = findViewById(R.id.text_view_power);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /*テストロジック*/
                String bucketName ="20-secretoptions-faces-search";
                String fileName = "test.jpg";
                try {

                    callLambda(bucketName, fileName,view,textViewDept,textViewName,textViewPower);

                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    /*カメラボタン押下時に起動させる機能*/
    public void sendPictureToS3(String fileName){

        /*ここにカメラで取得した画像ファイルをS３に送るロジックを記載する*/

    }

    /*lambda呼び出す機能*/
    public String callLambda(String bucketName, String fileName,View view,TextView textViewDept,TextView textViewName,TextView textViewPower) throws Exception {

        String postURL = "https://d0xz7hc68a.execute-api.ap-northeast-1.amazonaws.com/search/20-secretoptions-faces";

        AsyncTask asyncTask = new AyscTask(this,view,textViewDept,textViewName,textViewPower).execute(postURL,bucketName,fileName);

        return "callLambdaのReturn";

    }

}
