package com.example.displaytest;

public class InputS3Json {

    byte[] image;
    String bucketName;
    String fileName;

    InputS3Json(byte[] image, String bucketName, String fileName) {
        this.image = image;
        this.bucketName = bucketName;
        this.fileName = fileName;
    }

}
