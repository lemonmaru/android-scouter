package com.example.displaytest;

public class InputJson {
    String bucket;
    String key;

    InputJson(String bucket,String key){
        this.bucket = bucket;
        this.key = key;
    }
}
