
package com.example.displaytest;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Headers {

    @SerializedName("x-custom-header")
    @Expose
    public String xCustomHeader;

}