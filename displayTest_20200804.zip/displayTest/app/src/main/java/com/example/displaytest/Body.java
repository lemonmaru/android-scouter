
package com.example.displaytest;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Body {

    @SerializedName("tel")
    @Expose
    public String tel;
    @SerializedName("emp_num")
    @Expose
    public String empNum;
    @SerializedName("dept")
    @Expose
    public String dept;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("position")
    @Expose
    public String position;
    @SerializedName("power")
    @Expose
    public Float power;

}
