package com.example.displaytest;

import android.hardware.Camera;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    private TextView textViewDept;
    private TextView textViewName;
    private TextView textViewPower;
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;
    private static Camera mCamera = null;
    final File[] pictureFile = new File[1];
    private CameraPreview mPreview;
    private CameraHandlerThread mThread = null;
    private S3HandlerThread sThread = null;
    private SendS3Manager sendS3Manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton fab = findViewById(R.id.fab);

        /*カメラロジックSTART*/
        newOpenCamera();
        mPreview = new CameraPreview(this, mCamera);
        FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
        preview.addView(mPreview);

        //いえーーーーーーーい
        //いえーーーーーーーい

        /*カメラロジックEND*/

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //いえーーーーーーーい
                textViewDept = findViewById(R.id.text_view_dept);
                textViewName = findViewById(R.id.text_view_name);
                textViewPower = findViewById(R.id.text_view_power);
                //いえーーーーーーーい

                //☆☆参考　https://re-engines.com/2017/04/20/android-javaでs3への画像アップロード/

                try {
                    (new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //ここで処理時間の長い処理を実行する

                            /*カメラロジックSTART*/
                            mCamera.startPreview();
                            Camera.Parameters parameters = mCamera.getParameters();
                            parameters.setJpegQuality(75);
                            mCamera.setParameters(parameters);
                            mCamera.takePicture(null, null, mPicture);

                            /*カメラロジックEND*/
                        }
                    })).start();

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {

                }

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /*lambda呼び出す機能*/
    public String callLambda(String bucketName, String fileName, /*View view,*/ TextView textViewDept, TextView textViewName, TextView textViewPower) throws Exception {

        String postURL = "https://d0xz7hc68a.execute-api.ap-northeast-1.amazonaws.com/search/20-secretoptions-faces";

        AsyncTask asyncTask = new AyscTask(/*this, view, */textViewDept, textViewName, textViewPower).execute(postURL, bucketName, fileName);

        return "callLambdaのReturn";

    }


    private static Uri getOutputMediaFileUri(int type) {
        return Uri.fromFile(getOutputMediaFile(type));
    }

    /**
     * Create a File for saving an image or video
     */
    private static File getOutputMediaFile(int type) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.

        //File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MyCameraApp");
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "CueLab");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("CueLab", "failed to create directory " + mediaStorageDir.toString());
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
                    "IMG_" + timeStamp + ".jpg");
        } else if (type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
                    "VID_" + timeStamp + ".mp4");
        } else {
            return null;
        }

        return mediaFile;
    }

    public static Camera getCameraInstance() {
        try {
            mCamera = Camera.open(); // attempt to get a Camera instance
        } catch (Exception e) {
            // Camera is not available (in use or does not exist)
        }
        return mCamera; // returns null if camera is unavailable
    }

    Camera.PictureCallback mPicture = new Camera.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] data, Camera camera) {

            /*テストロジック*/
            String bucketName = "20-secretoptions-faces-search";
            String fileName;

            pictureFile[0] = getOutputMediaFile(MEDIA_TYPE_IMAGE);
            if (pictureFile[0] == null) {
                Log.d("pictureFile == null", "Error creating media file, check storage permissions");
                return;
            }

            try {
                FileOutputStream fos = new FileOutputStream(pictureFile[0]);
                fos.write(data);

                Log.d("file toString()", pictureFile[0].toString());

                //s3
                String url = "https://c0b3huv8k0.execute-api.ap-northeast-1.amazonaws.com/default/20-secretoptions-registerToS3";
                fileName = pictureFile[0].getName();

                Log.d("ここでのファイル名はー＞", pictureFile[0].toString());

                sendS3(url, bucketName, fileName, data);
                fos.close();
                //s3

                callLambda(bucketName, fileName, /*view,*/ textViewDept, textViewName, textViewPower);


            } catch (FileNotFoundException e) {
                Log.d("FileNotFoundException", "File not found: " + e.getMessage());
            } catch (IOException e) {
                Log.d("IOException", "Error accessing file: " + e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
                Log.d("Exception", "Error: " + e.getMessage());
            } finally {
                mCamera.stopPreview();
                mCamera.startPreview();
            }
        }
    };

    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();// release the camera immediately on pause event
    }

    private void releaseCamera() {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.setPreviewCallback(null);
            mCamera.release();        // release the camera for other applications
            mCamera = null;
        }
    }

    private void newOpenCamera() {
        if (mThread == null) {
            mThread = new CameraHandlerThread();
        }

        synchronized (mThread) {
            mThread.openCamera();
        }
    }

    private void sendS3(String url, String bucketName, String fileName, byte[] file) {
        sThread = null;
        sThread = new S3HandlerThread(url, bucketName, fileName, file);

        synchronized (sThread) {
            sThread.sendToS3();
        }
    }


    private static class CameraHandlerThread extends HandlerThread {
        Handler mHandler = null;

        CameraHandlerThread() {
            super("CameraHandlerThread");
            start();
            mHandler = new Handler(getLooper());
        }

        synchronized void notifyCameraOpened() {
            notify();
        }

        void openCamera() {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    getCameraInstance();
                    notifyCameraOpened();
                }
            });
            try {
                wait();
            } catch (InterruptedException e) {
                Log.w("これは", "wait was interrupted");
            }
        }
    }

    private static class S3HandlerThread extends HandlerThread {
        Handler mHandler = null;
        String url;
        String fileName;
        String bucketName;
        byte[] file;
        private SendS3Manager sendS3Manager;

        S3HandlerThread(String url, String bucketName, String fileName, byte[] file) {
            super("S3HandlerThread");
            this.url = url;
            this.fileName = fileName;
            this.bucketName = bucketName;
            this.file = file;
            start();
            mHandler = new Handler(getLooper());
        }

        synchronized void notifyCameraOpened() {
            notify();
        }

        void sendToS3() {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    Log.d("果たしてこちらのファイル名は", fileName);
                    sendS3Manager = new SendS3Manager();
                    //String url = "https://c0b3huv8k0.execute-api.ap-northeast-1.amazonaws.com/default/20-secretoptions-registerToS3";
                    sendS3Manager.sendToS3(url, bucketName, fileName, file);
                    notifyCameraOpened();
                }
            });
            try {
                wait();
            } catch (InterruptedException e) {
                Log.w("これは", "wait was interrupted");
            }
        }
    }

}
