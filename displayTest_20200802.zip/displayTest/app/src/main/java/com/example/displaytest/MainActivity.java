package com.example.displaytest;

import android.hardware.Camera;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    private TextView textViewDept;
    private TextView textViewName;
    private TextView textViewPower;
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;
    private static Camera mCamera = null;
    final File[] pictureFile = new File[1];
    private CameraPreview mPreview;
    private CameraHandlerThread mThread = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);

        /*カメラロジックSTART*/
        //mCamera = getCameraInstance();
        newOpenCamera();
        mPreview = new CameraPreview(this, mCamera);
        FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
        preview.addView(mPreview);

        TextView textViewDept = findViewById(R.id.text_view_dept);
        TextView textViewName = findViewById(R.id.text_view_name);
        TextView textViewPower = findViewById(R.id.text_view_power);
        /*カメラロジックEND*/

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //☆☆参考　https://stackoverflow.com/questions/21723557/java-lang-runtimeexception-takepicture-failed

                /*テストロジック*/
                String bucketName = "20-secretoptions-faces-search";
                String fileName = "test.jpg";

                try {
                    (new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //ここで処理時間の長い処理を実行する

                            /*カメラロジックSTART*/
                            mCamera.startPreview();
                            mCamera.takePicture(null, null, mPicture);

                            /*カメラロジックEND*/
                        }
                    })).start();


                    callLambda(bucketName, fileName, /*view,*/ textViewDept, textViewName, textViewPower);

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    //mCamera.release();
                }

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    /*カメラボタン押下時に起動させる機能*/
    public void sendPictureToS3(String fileName) {

        /*ここにカメラで取得した画像ファイルをS３に送るロジックを記載する*/

    }

    /*lambda呼び出す機能*/
    public String callLambda(String bucketName, String fileName, /*View view,*/ TextView textViewDept, TextView textViewName, TextView textViewPower) throws Exception {

        String postURL = "https://d0xz7hc68a.execute-api.ap-northeast-1.amazonaws.com/search/20-secretoptions-faces";

        AsyncTask asyncTask = new AyscTask(/*this, view, */textViewDept, textViewName, textViewPower).execute(postURL, bucketName, fileName);

        return "callLambdaのReturn";

    }


    private static Uri getOutputMediaFileUri(int type) {
        return Uri.fromFile(getOutputMediaFile(type));
    }

    /**
     * Create a File for saving an image or video
     */
    private static File getOutputMediaFile(int type) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "MyCameraApp");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("MyCameraApp", "failed to create directory");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
                    "IMG_" + timeStamp + ".jpg");
        } else if (type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
                    "VID_" + timeStamp + ".mp4");
        } else {
            return null;
        }

        return mediaFile;
    }

    public static Camera getCameraInstance() {
        try {
            mCamera = Camera.open(); // attempt to get a Camera instance
        } catch (Exception e) {
            // Camera is not available (in use or does not exist)
        }
        return mCamera; // returns null if camera is unavailable
    }

    Camera.PictureCallback mPicture = new Camera.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            Log.d("おーい", "処理入ってる？");
            pictureFile[0] = getOutputMediaFile(MEDIA_TYPE_IMAGE);
            if (pictureFile[0] == null) {
                Log.d("pictureFile == null", "Error creating media file, check storage permissions");
                return;
            }

            try {
                FileOutputStream fos = new FileOutputStream(pictureFile[0]);
                fos.write(data);
                fos.close();
                Log.d("file", pictureFile[0].toString());

            } catch (FileNotFoundException e) {
                Log.d("FileNotFoundException", "File not found: " + e.getMessage());
            } catch (IOException e) {
                Log.d("IOException", "Error accessing file: " + e.getMessage());
            }
        }
    };

    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();              // release the camera immediately on pause event
    }

    private void releaseCamera() {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.setPreviewCallback(null);
            mCamera.release();        // release the camera for other applications
            mCamera = null;
        }
    }

    private void newOpenCamera() {
        if (mThread == null) {
            mThread = new CameraHandlerThread();
        }

        synchronized (mThread) {
            mThread.openCamera();
        }
    }


    private static class CameraHandlerThread extends HandlerThread {
        Handler mHandler = null;

        CameraHandlerThread() {
            super("CameraHandlerThread");
            start();
            mHandler = new Handler(getLooper());
        }

        synchronized void notifyCameraOpened() {
            notify();
        }

        void openCamera() {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    getCameraInstance();
                    notifyCameraOpened();
                }
            });
            try {
                wait();
            } catch (InterruptedException e) {
                Log.w("これは", "wait was interrupted");
            }
        }
    }

}
