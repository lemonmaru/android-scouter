package com.example.displaytest;

import android.util.Log;

import com.google.gson.Gson;

import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class SendS3Manager {

    public int sendToS3(String url, String bucketName, String fileName, byte[] file) {
        StringBuffer result = new StringBuffer();

        HttpURLConnection urlConnection = null;
        int status = 0;
        try {
            URL sendUrl = new URL(url);

            urlConnection = (HttpURLConnection) sendUrl.openConnection();
            Gson gson = new Gson();

            InputS3Json isj = new InputS3Json(file, bucketName, fileName);
            String json = gson.toJson(isj, InputS3Json.class);

            urlConnection.setRequestProperty("Content-Length", String.valueOf(json.length()));
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setConnectTimeout(200000);
            urlConnection.setReadTimeout(200000);
            urlConnection.setRequestMethod("PUT");
            // データがJSONであること、エンコードを指定する
            urlConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            OutputStreamWriter out = new OutputStreamWriter(urlConnection.getOutputStream());

            out.write(json);
            out.flush();

            urlConnection.connect();
            status = urlConnection.getResponseCode();

            //通信成功の場合
            InputStream in = null;
            if (status == HttpURLConnection.HTTP_OK) {
                Log.d("成功", "成功、200");
                Log.d("bucketName", bucketName);
                Log.d("fileName", fileName);
            } else {
                Log.d("失敗", "失敗、200じゃない");
                Log.d("200じゃない理由→",urlConnection.getErrorStream().toString());
                Log.d("失敗status", Integer.toString(status));
            }

        } catch (Exception e) {
            Log.d("エラーです！", "エラーです！");
            Log.d("追跡ログ",e.getMessage());
        }

        return status;
    }
}
